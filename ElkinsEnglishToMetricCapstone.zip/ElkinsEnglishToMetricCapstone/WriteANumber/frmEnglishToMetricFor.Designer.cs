﻿namespace WriteANumber
{
    partial class frmEnglishToMetricForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEnter = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblYardsOutput = new System.Windows.Forms.Label();
            this.lblFeetOutput = new System.Windows.Forms.Label();
            this.lblInchesOutput = new System.Windows.Forms.Label();
            this.lblMeters = new System.Windows.Forms.Label();
            this.txtKilometersInput = new System.Windows.Forms.TextBox();
            this.lblCentimeters = new System.Windows.Forms.Label();
            this.lblMilesOutput = new System.Windows.Forms.Label();
            this.lblKilometers = new System.Windows.Forms.Label();
            this.txtCentimeterInput = new System.Windows.Forms.TextBox();
            this.txtMetersInput = new System.Windows.Forms.TextBox();
            this.grpMetricInput = new System.Windows.Forms.GroupBox();
            this.lblMetersOutput = new System.Windows.Forms.Label();
            this.lblCentimetersOutput = new System.Windows.Forms.Label();
            this.lblYards = new System.Windows.Forms.Label();
            this.lblFeet = new System.Windows.Forms.Label();
            this.lblKilometersOutput = new System.Windows.Forms.Label();
            this.lblInches = new System.Windows.Forms.Label();
            this.txtInchesInput = new System.Windows.Forms.TextBox();
            this.txtFeetInput = new System.Windows.Forms.TextBox();
            this.txtYardsInput = new System.Windows.Forms.TextBox();
            this.grpEnglishInput = new System.Windows.Forms.GroupBox();
            this.txtMilesInput = new System.Windows.Forms.TextBox();
            this.lblMiles = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.optEnglishConvert = new System.Windows.Forms.RadioButton();
            this.optMetricConverter = new System.Windows.Forms.RadioButton();
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpMetricInput.SuspendLayout();
            this.grpEnglishInput.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnEnter
            // 
            this.btnEnter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnter.Location = new System.Drawing.Point(642, 534);
            this.btnEnter.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(121, 35);
            this.btnEnter.TabIndex = 40;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click_1);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(131, 534);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(121, 35);
            this.btnExit.TabIndex = 38;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click_1);
            // 
            // lblYardsOutput
            // 
            this.lblYardsOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblYardsOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYardsOutput.Location = new System.Drawing.Point(148, 139);
            this.lblYardsOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblYardsOutput.Name = "lblYardsOutput";
            this.lblYardsOutput.Size = new System.Drawing.Size(134, 57);
            this.lblYardsOutput.TabIndex = 20;
            this.lblYardsOutput.Text = "Yards";
            this.lblYardsOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFeetOutput
            // 
            this.lblFeetOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFeetOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFeetOutput.Location = new System.Drawing.Point(292, 139);
            this.lblFeetOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFeetOutput.Name = "lblFeetOutput";
            this.lblFeetOutput.Size = new System.Drawing.Size(147, 57);
            this.lblFeetOutput.TabIndex = 19;
            this.lblFeetOutput.Text = "Feet";
            this.lblFeetOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblInchesOutput
            // 
            this.lblInchesOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblInchesOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInchesOutput.Location = new System.Drawing.Point(454, 139);
            this.lblInchesOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblInchesOutput.Name = "lblInchesOutput";
            this.lblInchesOutput.Size = new System.Drawing.Size(162, 57);
            this.lblInchesOutput.TabIndex = 18;
            this.lblInchesOutput.Text = "Inches";
            this.lblInchesOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMeters
            // 
            this.lblMeters.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMeters.Location = new System.Drawing.Point(252, 42);
            this.lblMeters.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMeters.Name = "lblMeters";
            this.lblMeters.Size = new System.Drawing.Size(96, 26);
            this.lblMeters.TabIndex = 17;
            this.lblMeters.Text = "Meters";
            this.lblMeters.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtKilometersInput
            // 
            this.txtKilometersInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKilometersInput.Location = new System.Drawing.Point(130, 70);
            this.txtKilometersInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtKilometersInput.Multiline = true;
            this.txtKilometersInput.Name = "txtKilometersInput";
            this.txtKilometersInput.Size = new System.Drawing.Size(105, 39);
            this.txtKilometersInput.TabIndex = 10;
            this.txtKilometersInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblCentimeters
            // 
            this.lblCentimeters.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCentimeters.Location = new System.Drawing.Point(367, 42);
            this.lblCentimeters.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCentimeters.Name = "lblCentimeters";
            this.lblCentimeters.Size = new System.Drawing.Size(96, 26);
            this.lblCentimeters.TabIndex = 16;
            this.lblCentimeters.Text = "Centimeters";
            this.lblCentimeters.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMilesOutput
            // 
            this.lblMilesOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblMilesOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMilesOutput.Location = new System.Drawing.Point(0, 139);
            this.lblMilesOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMilesOutput.Name = "lblMilesOutput";
            this.lblMilesOutput.Size = new System.Drawing.Size(132, 57);
            this.lblMilesOutput.TabIndex = 12;
            this.lblMilesOutput.Text = "Miles";
            this.lblMilesOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblKilometers
            // 
            this.lblKilometers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKilometers.Location = new System.Drawing.Point(132, 42);
            this.lblKilometers.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKilometers.Name = "lblKilometers";
            this.lblKilometers.Size = new System.Drawing.Size(96, 26);
            this.lblKilometers.TabIndex = 15;
            this.lblKilometers.Text = "Kilometers";
            this.lblKilometers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCentimeterInput
            // 
            this.txtCentimeterInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCentimeterInput.Location = new System.Drawing.Point(360, 70);
            this.txtCentimeterInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtCentimeterInput.Multiline = true;
            this.txtCentimeterInput.Name = "txtCentimeterInput";
            this.txtCentimeterInput.Size = new System.Drawing.Size(105, 39);
            this.txtCentimeterInput.TabIndex = 13;
            this.txtCentimeterInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMetersInput
            // 
            this.txtMetersInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMetersInput.Location = new System.Drawing.Point(244, 70);
            this.txtMetersInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtMetersInput.Multiline = true;
            this.txtMetersInput.Name = "txtMetersInput";
            this.txtMetersInput.Size = new System.Drawing.Size(105, 39);
            this.txtMetersInput.TabIndex = 14;
            this.txtMetersInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // grpMetricInput
            // 
            this.grpMetricInput.Controls.Add(this.lblYardsOutput);
            this.grpMetricInput.Controls.Add(this.lblFeetOutput);
            this.grpMetricInput.Controls.Add(this.lblInchesOutput);
            this.grpMetricInput.Controls.Add(this.lblMeters);
            this.grpMetricInput.Controls.Add(this.txtKilometersInput);
            this.grpMetricInput.Controls.Add(this.lblCentimeters);
            this.grpMetricInput.Controls.Add(this.lblMilesOutput);
            this.grpMetricInput.Controls.Add(this.lblKilometers);
            this.grpMetricInput.Controls.Add(this.txtCentimeterInput);
            this.grpMetricInput.Controls.Add(this.txtMetersInput);
            this.grpMetricInput.Location = new System.Drawing.Point(131, 322);
            this.grpMetricInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpMetricInput.Name = "grpMetricInput";
            this.grpMetricInput.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpMetricInput.Size = new System.Drawing.Size(628, 203);
            this.grpMetricInput.TabIndex = 34;
            this.grpMetricInput.TabStop = false;
            this.grpMetricInput.Visible = false;
            // 
            // lblMetersOutput
            // 
            this.lblMetersOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblMetersOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMetersOutput.Location = new System.Drawing.Point(190, 118);
            this.lblMetersOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMetersOutput.Name = "lblMetersOutput";
            this.lblMetersOutput.Size = new System.Drawing.Size(168, 56);
            this.lblMetersOutput.TabIndex = 11;
            this.lblMetersOutput.Text = "Meters";
            this.lblMetersOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCentimetersOutput
            // 
            this.lblCentimetersOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCentimetersOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCentimetersOutput.Location = new System.Drawing.Point(380, 118);
            this.lblCentimetersOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCentimetersOutput.Name = "lblCentimetersOutput";
            this.lblCentimetersOutput.Size = new System.Drawing.Size(169, 57);
            this.lblCentimetersOutput.TabIndex = 10;
            this.lblCentimetersOutput.Text = "Centimeters";
            this.lblCentimetersOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblYards
            // 
            this.lblYards.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYards.Location = new System.Drawing.Point(182, 36);
            this.lblYards.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblYards.Name = "lblYards";
            this.lblYards.Size = new System.Drawing.Size(96, 26);
            this.lblYards.TabIndex = 9;
            this.lblYards.Text = "Yards";
            this.lblYards.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFeet
            // 
            this.lblFeet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFeet.Location = new System.Drawing.Point(298, 36);
            this.lblFeet.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFeet.Name = "lblFeet";
            this.lblFeet.Size = new System.Drawing.Size(96, 26);
            this.lblFeet.TabIndex = 8;
            this.lblFeet.Text = "Feet";
            this.lblFeet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblKilometersOutput
            // 
            this.lblKilometersOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblKilometersOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKilometersOutput.Location = new System.Drawing.Point(5, 117);
            this.lblKilometersOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKilometersOutput.Name = "lblKilometersOutput";
            this.lblKilometersOutput.Size = new System.Drawing.Size(159, 57);
            this.lblKilometersOutput.TabIndex = 2;
            this.lblKilometersOutput.Text = "Kilometers";
            this.lblKilometersOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblInches
            // 
            this.lblInches.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInches.Location = new System.Drawing.Point(406, 36);
            this.lblInches.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblInches.Name = "lblInches";
            this.lblInches.Size = new System.Drawing.Size(96, 26);
            this.lblInches.TabIndex = 7;
            this.lblInches.Text = "Inches";
            this.lblInches.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtInchesInput
            // 
            this.txtInchesInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInchesInput.Location = new System.Drawing.Point(404, 64);
            this.txtInchesInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtInchesInput.Multiline = true;
            this.txtInchesInput.Name = "txtInchesInput";
            this.txtInchesInput.Size = new System.Drawing.Size(105, 39);
            this.txtInchesInput.TabIndex = 3;
            this.txtInchesInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtFeetInput
            // 
            this.txtFeetInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFeetInput.Location = new System.Drawing.Point(290, 64);
            this.txtFeetInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtFeetInput.Multiline = true;
            this.txtFeetInput.Name = "txtFeetInput";
            this.txtFeetInput.Size = new System.Drawing.Size(105, 39);
            this.txtFeetInput.TabIndex = 4;
            this.txtFeetInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtYardsInput
            // 
            this.txtYardsInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtYardsInput.Location = new System.Drawing.Point(174, 64);
            this.txtYardsInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtYardsInput.Multiline = true;
            this.txtYardsInput.Name = "txtYardsInput";
            this.txtYardsInput.Size = new System.Drawing.Size(105, 39);
            this.txtYardsInput.TabIndex = 5;
            this.txtYardsInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // grpEnglishInput
            // 
            this.grpEnglishInput.Controls.Add(this.lblMetersOutput);
            this.grpEnglishInput.Controls.Add(this.lblCentimetersOutput);
            this.grpEnglishInput.Controls.Add(this.lblYards);
            this.grpEnglishInput.Controls.Add(this.txtMilesInput);
            this.grpEnglishInput.Controls.Add(this.lblFeet);
            this.grpEnglishInput.Controls.Add(this.lblKilometersOutput);
            this.grpEnglishInput.Controls.Add(this.lblInches);
            this.grpEnglishInput.Controls.Add(this.txtInchesInput);
            this.grpEnglishInput.Controls.Add(this.lblMiles);
            this.grpEnglishInput.Controls.Add(this.txtFeetInput);
            this.grpEnglishInput.Controls.Add(this.txtYardsInput);
            this.grpEnglishInput.Location = new System.Drawing.Point(165, 127);
            this.grpEnglishInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpEnglishInput.Name = "grpEnglishInput";
            this.grpEnglishInput.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpEnglishInput.Size = new System.Drawing.Size(574, 180);
            this.grpEnglishInput.TabIndex = 33;
            this.grpEnglishInput.TabStop = false;
            // 
            // txtMilesInput
            // 
            this.txtMilesInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMilesInput.Location = new System.Drawing.Point(60, 64);
            this.txtMilesInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtMilesInput.Multiline = true;
            this.txtMilesInput.Name = "txtMilesInput";
            this.txtMilesInput.Size = new System.Drawing.Size(105, 39);
            this.txtMilesInput.TabIndex = 0;
            this.txtMilesInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblMiles
            // 
            this.lblMiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiles.Location = new System.Drawing.Point(63, 36);
            this.lblMiles.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMiles.Name = "lblMiles";
            this.lblMiles.Size = new System.Drawing.Size(96, 26);
            this.lblMiles.TabIndex = 6;
            this.lblMiles.Text = "Miles";
            this.lblMiles.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(402, 534);
            this.btnClear.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(121, 35);
            this.btnClear.TabIndex = 39;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click_1);
            // 
            // optEnglishConvert
            // 
            this.optEnglishConvert.AutoSize = true;
            this.optEnglishConvert.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optEnglishConvert.Location = new System.Drawing.Point(113, 89);
            this.optEnglishConvert.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.optEnglishConvert.Name = "optEnglishConvert";
            this.optEnglishConvert.Size = new System.Drawing.Size(311, 19);
            this.optEnglishConvert.TabIndex = 35;
            this.optEnglishConvert.Text = "Choose Convert English Units to Metric Units\r\n";
            this.optEnglishConvert.UseVisualStyleBackColor = true;
            this.optEnglishConvert.CheckedChanged += new System.EventHandler(this.optEnglishConvert_CheckedChanged_1);
            // 
            // optMetricConverter
            // 
            this.optMetricConverter.AutoSize = true;
            this.optMetricConverter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optMetricConverter.Location = new System.Drawing.Point(498, 89);
            this.optMetricConverter.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.optMetricConverter.Name = "optMetricConverter";
            this.optMetricConverter.Size = new System.Drawing.Size(311, 19);
            this.optMetricConverter.TabIndex = 37;
            this.optMetricConverter.Text = "Choose Convert Metric Units to English Units";
            this.optMetricConverter.UseVisualStyleBackColor = true;
            this.optMetricConverter.CheckedChanged += new System.EventHandler(this.optMetricConverter_CheckedChanged_1);
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(278, 41);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(300, 40);
            this.lblTitle.TabIndex = 36;
            this.lblTitle.Text = "English And Metric Converter";
            // 
            // frmEnglishToMetricForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(976, 611);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.grpMetricInput);
            this.Controls.Add(this.grpEnglishInput);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.optEnglishConvert);
            this.Controls.Add(this.optMetricConverter);
            this.Controls.Add(this.lblTitle);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmEnglishToMetricForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Write A Number";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmEnglishToMetricForm_Load);
            this.grpMetricInput.ResumeLayout(false);
            this.grpMetricInput.PerformLayout();
            this.grpEnglishInput.ResumeLayout(false);
            this.grpEnglishInput.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblYardsOutput;
        private System.Windows.Forms.Label lblFeetOutput;
        private System.Windows.Forms.Label lblInchesOutput;
        private System.Windows.Forms.Label lblMeters;
        private System.Windows.Forms.TextBox txtKilometersInput;
        private System.Windows.Forms.Label lblCentimeters;
        private System.Windows.Forms.Label lblMilesOutput;
        private System.Windows.Forms.Label lblKilometers;
        private System.Windows.Forms.TextBox txtCentimeterInput;
        private System.Windows.Forms.TextBox txtMetersInput;
        private System.Windows.Forms.GroupBox grpMetricInput;
        private System.Windows.Forms.Label lblMetersOutput;
        private System.Windows.Forms.Label lblCentimetersOutput;
        private System.Windows.Forms.Label lblYards;
        private System.Windows.Forms.Label lblFeet;
        private System.Windows.Forms.Label lblKilometersOutput;
        private System.Windows.Forms.Label lblInches;
        private System.Windows.Forms.TextBox txtInchesInput;
        private System.Windows.Forms.TextBox txtFeetInput;
        private System.Windows.Forms.TextBox txtYardsInput;
        private System.Windows.Forms.GroupBox grpEnglishInput;
        private System.Windows.Forms.TextBox txtMilesInput;
        private System.Windows.Forms.Label lblMiles;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.RadioButton optEnglishConvert;
        private System.Windows.Forms.RadioButton optMetricConverter;
        private System.Windows.Forms.Label lblTitle;
    }
}

