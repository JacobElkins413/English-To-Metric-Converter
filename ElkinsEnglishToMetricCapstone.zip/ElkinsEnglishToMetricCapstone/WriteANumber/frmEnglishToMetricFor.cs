﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WriteANumber
{
    public partial class frmEnglishToMetricForm : Form
    {
        public frmEnglishToMetricForm()
        {
            InitializeComponent();
        }

        private void frmEnglishToMetricForm_Load(object sender, EventArgs e)
        {
            //grpConverter.Left = (int)(Screen.GetWorkingArea(this).Width / 2 - grpConverter.Width/2);

            grpEnglishInput.Visible = false;
            grpMetricInput.Visible = false;
        }

        private double roundNumber(double temp, int numberOfDigitsToTheRightOfDecimalPoint)
        {
            if (optEnglishConvert.Checked)
            {
                temp = temp * exponentiate(Convert.ToInt16(numberOfDigitsToTheRightOfDecimalPoint));
                temp += .5;
                temp = (int)temp;
                temp = temp / exponentiate(Convert.ToInt16(numberOfDigitsToTheRightOfDecimalPoint));
                return temp;
            }

            else
            {
                temp = temp * exponentiate(Convert.ToInt16(numberOfDigitsToTheRightOfDecimalPoint));
                temp += .5;
                temp = (int)temp;
                temp = temp / exponentiate(Convert.ToInt16(numberOfDigitsToTheRightOfDecimalPoint));
                return temp;
            }
        }

        private int exponentiate(int powerOfT10)
        {
            if (powerOfT10 == 0)
                return 1;

            int result = 10;
            for (int n = 0; n < powerOfT10 - 1; n++)
                result *= 10;

            return result;
        }

        private bool canBePositiveDouble(string temp, String userMessage2)
        {
            try
            {
                Convert.ToDouble(temp);
                if (temp[0] == '-')
                    return false;
                return true;
            }
            catch
            {
                MessageBox.Show(userMessage2);
                return false;
            }
        }


        private bool canBePositiveInt(String temp, String userMessage)
        {
            try
            {
                if (Convert.ToInt32(temp) > -1)
                    return true;

                return false;
            }
            catch
            {

                MessageBox.Show(userMessage);

                return false;

            }
        }

        private void optEnglishConvert_CheckedChanged_1(object sender, EventArgs e)
        {
            //make english input visible
            //make metric input not visible 
            if (optEnglishConvert.Checked)
                grpEnglishInput.Visible = true;
            grpMetricInput.Visible = false;
        }

        private void optMetricConverter_CheckedChanged_1(object sender, EventArgs e)
        {
            //make metric input visible
            //make english input invisible

            if (optMetricConverter.Checked)
                grpMetricInput.Visible = true;
            grpEnglishInput.Visible = false;
        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnClear_Click_1(object sender, EventArgs e)
        {
            txtCentimeterInput.Clear();
            txtFeetInput.Clear();
            txtInchesInput.Clear();
            txtKilometersInput.Clear();
            txtMetersInput.Clear();
            txtMilesInput.Clear();
            txtYardsInput.Clear();

            lblKilometersOutput.Text = "";
            lblMetersOutput.Text = "";
            lblCentimetersOutput.Text = "";
            lblMilesOutput.Text = "";
            lblYardsOutput.Text = "";
            lblFeetOutput.Text = "";
            lblInchesOutput.Text = "";
        }

        private void btnEnter_Click_1(object sender, EventArgs e)
        {
            if (optEnglishConvert.Checked)
            {
                if (txtMilesInput.Text.Length == 0)
                    txtMilesInput.Text = "0";
                if (txtYardsInput.Text.Length == 0)
                    txtYardsInput.Text = "0";
                if (txtFeetInput.Text.Length == 0)
                    txtFeetInput.Text = "0";
                if (txtInchesInput.Text.Length == 0)
                    txtInchesInput.Text = "0";


                String userMessage = "must be an integer";
                String userMessage2 = "must be an integer";

                if (canBePositiveInt(txtMilesInput.Text, userMessage))
                {
                    if (canBePositiveInt(txtYardsInput.Text, userMessage))
                    {
                        if (canBePositiveInt(txtFeetInput.Text, userMessage))
                        {
                            if (canBePositiveDouble(txtInchesInput.Text, userMessage2))

                            {
                                CapstoneEnglishToMetric.ConvertEnlgishToMetric E2M = new CapstoneEnglishToMetric.ConvertEnlgishToMetric
                                    (txtMilesInput.Text, txtYardsInput.Text, txtFeetInput.Text, txtInchesInput.Text);

                                //call a convert method that instantiates E2M and sends arguments

                                lblKilometersOutput.Text = Convert.ToInt32(E2M.get_Kilometers()).ToString();
                                lblMetersOutput.Text = Convert.ToInt32(E2M.get_Meters()).ToString();

                                lblCentimetersOutput.Text = roundNumber(Convert.ToDouble(E2M.get_Centimeters()), 2).ToString();
                            }

                        }
                    }
                }
            }

            else
            {
                if (txtKilometersInput.Text.Length == 0)
                    txtKilometersInput.Text = "0";
                if (txtMetersInput.Text.Length == 0)
                    txtMetersInput.Text = "0";
                if (txtCentimeterInput.Text.Length == 0)
                    txtCentimeterInput.Text = "0";

                String userMessage = "must me integer";
                String userMessage2 = "must be integer or double";

                if (canBePositiveInt(txtKilometersInput.Text, userMessage))
                {
                    if (canBePositiveInt(txtMetersInput.Text, userMessage))
                    {
                        if (canBePositiveDouble(txtCentimeterInput.Text, userMessage2))
                        {

                            CapstoneEnglishToMetric.ConvertMetricToEnglish M2E = new CapstoneEnglishToMetric.ConvertMetricToEnglish
                                (txtKilometersInput.Text, txtMetersInput.Text, txtCentimeterInput.Text);
                            //call a convert method that instantiates M2E and sends arguments


                            lblMilesOutput.Text = Convert.ToInt32(M2E.get_Miles()).ToString();
                            lblYardsOutput.Text = Convert.ToInt32(M2E.get_Yards()).ToString();
                            lblFeetOutput.Text = Convert.ToInt32(M2E.get_Feet()).ToString();



                            lblInchesOutput.Text = roundNumber(Convert.ToDouble(M2E.get_Inches()), 2).ToString();


                        }
                    }
                }
            }
        }
    }
}
                    

            
        
    
