﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapstoneEnglishToMetric
{
    class ConvertEnlgishToMetric
    {
        private int _miles;
        private int _yards;
        private int _feet;
        private double _inches;
        private int _kilometers;
        private int _meters;
        private double _centimeters;

        public ConvertEnlgishToMetric (String mile, String yard, String feet, String inches)
        {
            _miles = Convert.ToInt32(mile);
            _yards = Convert.ToInt32(yard);
            _feet = Convert.ToInt32(feet);
            _inches = Convert.ToInt32(inches);

            _kilometers = 0;
            _meters = 0;
            _centimeters = 0;

            convertAllUnitsToInches();
        }

        public String get_Kilometers()
        {
            return _kilometers.ToString();
        }

        public String get_Meters()
        {
            return _meters.ToString();
        }

        public String get_Centimeters()
        {
            return _centimeters.ToString();
        }

        private void convertAllUnitsToInches()
        {
            //indicate the number of inches in centimeters, meters and kilometers

            _yards += _miles * 1760; //1760 yards in a mile
            _feet += _yards * 3; // 3 feet in a yard
            _inches += _feet * 12; // 12 inches in a foot

            convertInchToCm();

        }

        private void convertInchToCm()
        {
            //indicate the number of inches entered in centimeters
            // 1 inch = 2.54 cm

            _centimeters = _inches * 2.54;

            extractKmFromCm();
            extractMetersFromCm();

        }

        private void extractMetersFromCm()
        {
            //take out the number of meters in the converted centimeters
            // 1 meter = 100 cm

            _meters = (int)_centimeters / 100;
            //integer division

            _centimeters = _centimeters % 100;
            //modulus

        }

        private void extractKmFromCm()
        {
            //take out the number of kilometers in the converted centimeters
            // 1 km = 100,000 cm

            _kilometers = (int)_centimeters / 100000;
            //integer division 
            //centimeters in this line of code is an int only here since it was made a double 

            _centimeters = _centimeters % 100000;
            // modulus
            //this gets the decimal places 

        }

        private void round_CentimetersToTwoDecimalPlaces()
        {
            //make sure centimeters is only two decimal places

            _centimeters = _centimeters * 100;
            _centimeters = (int)_centimeters;
            _centimeters = _centimeters / 100;
        }
    }
}
