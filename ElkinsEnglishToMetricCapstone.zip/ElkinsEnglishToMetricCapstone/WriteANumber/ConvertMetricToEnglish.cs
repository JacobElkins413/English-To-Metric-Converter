﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapstoneEnglishToMetric
{
    class ConvertMetricToEnglish
    {
        private int _miles;
        private int _yards;
        private int _feet;
        private double _inches;
        private int _kilometers;
        private int _meters;
        private double _centimeters;

        public ConvertMetricToEnglish(String kilometers, String meters, String centimeters)
        {
            _miles = 0;
            _yards = 0;
            _feet = 0;
            _inches = 0;

            _kilometers = Convert.ToInt32(kilometers);
            _meters = Convert.ToInt32(meters);
            _centimeters = Convert.ToInt32(centimeters);

            convertAllUnitsToCm();
        }

        public String get_Miles()
        {
            return _miles.ToString();
        }

        public String get_Yards()
        {
            return _yards.ToString();
        }

        public String get_Feet()
        {
            return _feet.ToString();
        }

        public String get_Inches()
        {
            return _inches.ToString();
        }

        private void convertAllUnitsToCm()
        {
            //indicate the number of kilometers in inches, feet, yards and miles


            _meters += _kilometers * 1000;
            _centimeters += _meters * 100;

            convertCmToInches();
        }

        private void convertCmToInches()
        {
            //indicate the number of inches in a centimeter
            // 0.393700787 

            _inches = _centimeters * 0.393700787;

            extractMilesFromIches();
            extractYardsFromInches();
            extractFeetFromInches();

        }

        private void extractMilesFromIches()
        {
            //take out the number of miles in the converted inches
            // 1 mile = 63,360 inches

            _miles = (int)_inches / 63360;

            _inches = _inches % 63360;
        }

        private void extractYardsFromInches()
        {
            //take out the number of yards in the converted inches
            // 1 yard = 36 inches

            _yards = (int)_inches / 36;

            _inches = _inches % 36;
        }

        private void extractFeetFromInches()
        {
            //take out the number of feet in the converted inches
            // 1 foot = 12 inches

            _feet = (int)_inches / 12;

            _inches = _inches % 12;
        }

        private void round_InchesToTwoDecimalPlaces()
        {
            //round inches to two decimal places

            _inches = _inches * 100;
            _inches = (int)_inches;
            _inches = _inches / 100;

            //ask how to accommodate any number of decimal places
        }
    }
}
